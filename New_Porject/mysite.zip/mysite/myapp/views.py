from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response

# Create your views here.

from django.http import HttpResponse


def index(request):
    return HttpResponse("Hello, world. You're at the views.py file.")


@api_view(["POST"])
def upload(request):
    data=request.data

    if (data["site"]=="s3"):
        print("s3")
    elif(data["site"]=="Onedrive"):
        print("Onedrive")
    elif(data["site"]=="drive"):
        print("drive")
    elif(data["site"]=="dropbox"):
        print("dropbox")
    else:
        print("Invalid Request")


    print("the file location is",data["file_location"])
    return Response('200')